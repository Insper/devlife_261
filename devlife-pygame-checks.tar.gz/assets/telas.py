import pygame
import random
from sprites import *

class TelaGameOver:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.window = pygame.display.set_mode((self.width, self.height))

        # ----- Carrega Fontes
        self.fonte = pygame.font.Font('assets/font/PressStart2P.ttf', 20)

    def update(self):
        for event in pygame.event.get():
            # ----- Verifica Sair
            if event.type == pygame.QUIT:
                return -1
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                    return -1
                else: # Qualquer outra tecla
                    return 1  # Vai direto para o jogo (tela resetada)
        return 3

    def desenha(self):
        # Fundo preto
        self.window.fill((0, 0, 0))

        # Texto
        texto1 = "Game Over"
        texto2 = "Pressione qualquer tecla"
        texto3 = "para jogar novamente"
        texto4 = "Q para sair"

        texto1 = self.fonte.render(texto1, True, (255, 255, 255))
        texto2 = self.fonte.render(texto2, True, (255, 255, 255))
        texto3 = self.fonte.render(texto3, True, (255, 255, 255))
        texto4 = self.fonte.render(texto4, True, (255, 255, 255))
        
        self.window.blit(texto1, (self.width//2 - texto1.get_width()//2, self.height//2 - 100))
        self.window.blit(texto2, (self.width//2 - texto2.get_width()//2, self.height//2 - 20))
        self.window.blit(texto3, (self.width//2 - texto3.get_width()//2, self.height//2 + 20))
        self.window.blit(texto4, (self.width//2 - texto4.get_width()//2, self.height//2 + 80))

        # ----- Atualiza estado do jogo
        pygame.display.update()  # Mostra o novo frame para o jogador

class TelaInicial:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.window = pygame.display.set_mode((self.width, self.height))

        # ----- Carrega Fontes
        self.fonte = pygame.font.Font('assets/font/PressStart2P.ttf', 20)

    def update(self):
        for event in pygame.event.get():
            # ----- Verifica Sair
            if event.type == pygame.QUIT:
                return -1
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                    return -1
                else: # Qualquer outra tecla
                    return 1  # Começa o jogo
        return 0

    def desenha(self):
        # Fundo preto
        self.window.fill((0, 0, 0))

        # Texto
        texto1 = "Pressione qualquer"
        texto2 = "tecla para começar"
        texto3 = "Q para sair"

        texto1 = self.fonte.render(texto1, True, (255, 255, 255))
        texto2 = self.fonte.render(texto2, True, (255, 255, 255))
        texto3 = self.fonte.render(texto3, True, (255, 255, 255))
        self.window.blit(texto1, (self.width//2 - texto1.get_width()//2, self.height//2 - 100))
        self.window.blit(texto2, (self.width//2 - texto2.get_width()//2, self.height//2))
        self.window.blit(texto3, (self.width//2 - texto3.get_width()//2, self.height//2 + 100))
        
        # ----- Atualiza estado do jogo
        pygame.display.update()  # Mostra o novo frame para o jogador

class TelaJogo:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.window = pygame.display.set_mode((self.width, self.height))

        self.nave = Nave(self.width, self.height)

        # ----- Carrega imagens
        fundo = pygame.image.load('assets/img/starfield.png')
        self.fundo = pygame.transform.scale(fundo, (self.width, self.height))

        # ----- Carrega sons
        self.musica_fundo = pygame.mixer.music.load('assets/snd/tgfcoder-FrozenJam-SeamlessLoop.ogg')
        self.som_tiro = pygame.mixer.Sound('assets/snd/pew.ogg')

        # ----- Carrega Fontes
        self.fonte = pygame.font.Font('assets/font/PressStart2P.ttf', 20)

        # ----- Chars
        self.coracoes = chr(9829) # Unicode para coração

        # ----- Gera estrelas
        self.estrelas = []
        for i in range(50):
            x = random.randrange(0, self.width)
            y = random.randrange(0, self.height)
            r = random.randrange(1, 4)
            self.estrelas.append([(x, y), r])

        # ----- Gera asteroides
        self.number_of_asteroids = 15

        self.asteroides = pygame.sprite.Group()
        for i in range(self.number_of_asteroids):
            a = Asteroides(self.width, self.height)
            self.asteroides.add(a)
        
        # ----- State
        self.vidas = 3
        self.max_vidas = 3
        self.t0 = pygame.time.get_ticks()
        self.fps = 0.
        self.musica_fundo = False

        # ----- Tiros
        self.tiros = pygame.sprite.Group()

        # ---- Explosoes
        self.explosoes = pygame.sprite.Group()

    def update(self):
        for event in pygame.event.get():
            # ----- Verifica Sair
            if event.type == pygame.QUIT:
                return -1
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                    return -1
            
            # ----- Atualiza estado teclas
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.som_tiro.play()
                    # Cria um novo tiro
                    tiro = Tiro(self.nave.rect.centerx, self.nave.rect.top)
                    self.tiros.add(tiro)
                else:
                    self.nave.keydown_event(event)
            if event.type == pygame.KEYUP:
                self.nave.keyup_event(event)

        # ----- Atualiza posicao nave
        self.nave.update()

        # ----- Atualiza asteroides
        self.asteroides.update()

        # ----- Atualiza tiros
        self.tiros.update()

        # ----- Verifica colisões
        colisao = pygame.sprite.spritecollide(self.nave, self.asteroides, True)

        if colisao:
            self.vidas -= 1
            if self.vidas <= 0:
                return 2  # Game Over
            
        # Verifica colisões tiros com asteroides
        colisao = pygame.sprite.groupcollide(self.tiros, self.asteroides, True, True)
        # Cria explosoes nas colisões
        for tiro, asteroides in colisao.items():
            for asteroide in asteroides:
                explosao = Explosao(asteroide.rect.centerx, asteroide.rect.centery)
                self.explosoes.add(explosao)

        # ----- Reconstitui asteroides
        while len(self.asteroides) < self.number_of_asteroids:
            a = Asteroides(self.width, self.height)
            self.asteroides.add(a)

        # ----- Musica de fundo
        if self.musica_fundo == False:
            pygame.mixer.music.play(-1)
            self.musica_fundo = True

        return True

    def desenha(self):
        self.window.fill((0, 0, 0)) # Preto

        self.window.blit(self.fundo, (0, 0))  # Desenha o fundo
        for estrela in self.estrelas:
            pos, r = estrela
            pygame.draw.circle(self.window, (255, 255, 255), pos, r)

        # ----- Desenha textos
        texto = self.fonte.render(self.coracoes * self.max_vidas, True, (255, 255, 255))
        self.window.blit(texto, (10, 10))    
        texto = self.fonte.render(self.coracoes * self.vidas, True, (255, 0, 0))
        self.window.blit(texto, (10, 10))

        # ----- Desenha FPS
        t1 = pygame.time.get_ticks()
        fps = 1000 / (t1 - self.t0)
        self.t0 = t1
        self.fps = fps
        texto = self.fonte.render(f'FPS: {int(fps)}', True, (255, 255, 0))
        self.window.blit(texto, (400, 10))

        # ----- Desenha tiros
        self.tiros.draw(self.window)

        # ----- Desenha nave
        self.nave.draw(self.window)

        # ----- Desenha asteroides
        for asteroide in self.asteroides:
            asteroide.draw(self.window)
        
        # ----- Desenha explosoes
        for explosao in self.explosoes:
            explosao.draw(self.window)
            explosao.update()
            if explosao.finished:
                self.explosoes.remove(explosao)

        # ----- Atualiza estado do jogo
        pygame.display.update()  # Mostra o novo frame para o jogador

