import pygame
import random

class Nave(pygame.sprite.Sprite):
    def __init__(self, WIDTH, HEIGHT):
        super().__init__()
        self.imagem = pygame.image.load('assets/img/playerShip1_orange.png')
        self.image = pygame.transform.scale(self.imagem, (50, 38))

        self.WIDTH = WIDTH
        self.HEIGHT = HEIGHT

        self.rect = self.image.get_rect()
        self.rect.center = (self.WIDTH // 2, self.HEIGHT - 100)

        self.vel = 0.1

        self.key_state = {
            'UP': False,
            'DOWN': False,
            'LEFT': False,
            'RIGHT': False,
        }

        self.t0 = pygame.time.get_ticks()

    def keydown_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                self.key_state['UP'] = True
            if event.key == pygame.K_s:
                self.key_state['DOWN'] = True
            if event.key == pygame.K_a:
                self.key_state['LEFT'] = True
            if event.key == pygame.K_d:
                self.key_state['RIGHT'] = True

    def keyup_event(self, event):
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                self.key_state['UP'] = False
            if event.key == pygame.K_s:
                self.key_state['DOWN'] = False
            if event.key == pygame.K_a:
                self.key_state['LEFT'] = False
            if event.key == pygame.K_d:
                self.key_state['RIGHT'] = False
    
    def update(self):
        x, y = self.rect.x, self.rect.y
        x_, y_ = x, y
        t1 = pygame.time.get_ticks()
        dt = 1000 / (t1 - self.t0)


        if self.key_state['UP']:
            y_ = y - self.vel * dt
        if self.key_state['DOWN']:
            y_ = y + self.vel * dt
        if self.key_state['LEFT']:
            x_ = x - self.vel * dt
        if self.key_state['RIGHT']:
            x_ = x + self.vel * dt

        if x_ < 0 or x_ > self.WIDTH - self.rect.width: 
            x_ = x
        if y_ < 0 or y_ > self.HEIGHT - self.rect.height:
            y_ = y

        self.rect.x = x_
        self.rect.y = y_

        self.t0 = t1

    def draw(self, surface):
        surface.blit(self.image, self.rect)

class Asteroides(pygame.sprite.Sprite):
    def __init__(self, WIDTH, HEIGHT):
        super().__init__()
        self.imagem = pygame.image.load('assets/img/meteorBrown_med1.png')

        w = random.randint(30, 60)
        h = random.randint(20, 40)
        self.imagem = pygame.transform.scale(self.imagem, (w, h))

        self.rect = self.imagem.get_rect()      
        self.rect.x = random.randrange(0, WIDTH - self.rect.width)
        self.rect.y = random.randrange(-500, -100)

        self.WIDTH = WIDTH
        self.HEIGHT = HEIGHT

        self.vel = random.uniform(0.1, 0.5) / 10
        self.t0 = pygame.time.get_ticks()

    def update(self):
        """Atualiza a posição do asteroide."""
        t1 = pygame.time.get_ticks()
        dt = 1000 / (t1 - self.t0)
        self.rect.y += self.vel * dt
        self.t0 = t1

        # Se o asteroide sair da tela MATE
        if self.rect.y > self.HEIGHT:
            self.kill()

    def draw(self, surface):
        """Desenha o asteroide na superfície fornecida."""
        surface.blit(self.imagem, self.rect)

class Tiro(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.imagem = pygame.image.load('assets/img/laserRed16.png')
        self.image = pygame.transform.scale(self.imagem, (20, 40))

        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        self.vel = 0.3
        self.t0 = -1

    def update(self):
        t1 = pygame.time.get_ticks()
        dt = 1000 / (t1 - self.t0)
        self.rect.y -= self.vel * dt
        self.t0 = t1

        # Se o tiro sair da tela MATE
        if self.rect.y < -self.rect.height:
            self.kill()

    def draw(self, surface):
        surface.blit(self.image, self.rect)

class Explosao(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = []
        for i in range(9):
            img = pygame.image.load(f'assets/img/regularExplosion0{i}.png')
            img = pygame.transform.scale(img, (50, 50))
            self.frames.append(img)
        
        self.current_frame = 0
        self.image = self.frames[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        self.t0 = pygame.time.get_ticks()
        self.frame_rate = 50  # Tempo entre frames em ms
        self.finished = False

    def update(self):
        t1 = pygame.time.get_ticks()
        if t1 - self.t0 > self.frame_rate:
            self.current_frame += 1
            if self.current_frame >= len(self.frames):
                self.finished = True
            else:
                self.image = self.frames[self.current_frame]
                self.t0 = t1
    
    def draw(self, surface):
        surface.blit(self.image, self.rect)
