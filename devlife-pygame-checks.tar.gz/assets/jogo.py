import funcoes
import pygame
from telas import *

def game_loop(telas):
    game = 0
    clock = pygame.time.Clock()
    while True:
        game = telas[game].update()
        if game == -1:
            break
            
        if game == 2:  # Jogador perdeu
            # Reseta a tela de jogo para a próxima partida
            telas[1] = TelaJogo(telas[1].width, telas[1].height)
            game = 3  # Vai para GameOver
        
        telas[game].desenha()
        clock.tick(60)
    return

pygame.init()
pygame.display.set_caption('Jogo Pygame')

width, height = 600, 900

telas = {0: TelaInicial(width, height), 1: TelaJogo(width, height), 2: '', 3: TelaGameOver(width, height)}

game_loop(telas)