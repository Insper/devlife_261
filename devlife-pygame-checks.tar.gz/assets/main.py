import asyncio
import pygame
from telas import *

async def main():
    pygame.init()
    pygame.display.set_caption('Jogo Pygame')

    width, height = 600, 900

    telas = {0: TelaInicial(width, height), 1: TelaJogo(width, height), 2: '', 3: TelaGameOver(width, height)}
    game = 0
    clock = pygame.time.Clock()

    while True:
        # Atualiza a tela atual
        game = telas[game].update()
        
        # Se retornar -1, o jogo deve ser encerrado
        if game == -1:
            break
            
        # Se retornar 2, significa que o jogador perdeu
        if game == 2:
            # Reseta a tela de jogo para a próxima partida
            telas[1] = TelaJogo(telas[1].width, telas[1].height)
            game = 3  # Vai para TelaGameOver
        
        # Desenha a tela atual
        telas[game].desenha()
        
        # Rendimento de controle para o browser (Obrigatório no Pygbag/Wasm)
        await asyncio.sleep(0)
        
        # Controla o framerate
        clock.tick(60)

# Inicializa o loop assíncrono
asyncio.run(main())
